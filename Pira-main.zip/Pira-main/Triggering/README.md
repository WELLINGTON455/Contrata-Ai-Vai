Codes for the Answer Triggering benchmark.

There are 2 script files:

1. 'naive_bayes.py': Loop for generating the results of the naive bayes and class assignment baselines.

2. 'AT_finetuning.py': Loop for generating the results of the transformer models ('bert-base-uncased', 'bert-large-uncased', 'roberta-base', 'roberta-large').

The '.csv' files contain the results of the two tests.
