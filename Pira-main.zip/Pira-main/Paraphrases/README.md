This folder contains the scripts used to generate the paraphrases in both English and Portuguese. 

Files:

- Pegasus_paraphraser: script for generating paraphrases in English

- PTT5-Paraphraser: script for generating paraphrases in Portuguese

The PTT5-Paraphraser model is provided under request, given its size
