Script for fine-tuning models in the CGQA task. 

The script is prepared to run a single model. One only has to set the MODEL_CHECKPOINT parameter.

Four models were tested in the paper: T5 base, T5 large, PTT5, and mT5. The first two models are for English and the last two for Portuguese. Other models can be tested: just remember of setting the appropriate languege (this has already been made for the four models used in the paper).

